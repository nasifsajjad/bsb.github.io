document.addEventListener('DOMContentLoaded', function() {
    const mobileToggle = document.getElementById('mobileToggle');
    const navMenu = document.querySelector('.nav-menu');
    const navItems = document.querySelectorAll('.nav-item');
    const currentYear = document.getElementById('current-year');
    
    // Set current year in footer
    currentYear.textContent = new Date().getFullYear();
    
    // Mobile menu toggle
    mobileToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
        this.innerHTML = navMenu.classList.contains('active') ? '✕' : '☰';
        document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    });
    
    // Add dropdown toggles to mobile menu items
    navItems.forEach(item => {
        if (item.querySelector('.dropdown-menu')) {
            const dropdownToggle = document.createElement('span');
            dropdownToggle.className = 'dropdown-toggle';
            dropdownToggle.innerHTML = '<i class="fas fa-chevron-down"></i>';
            item.querySelector('.nav-link').appendChild(dropdownToggle);
        }
    });
    
    // Dropdown toggle functionality
    document.querySelectorAll('.nav-item').forEach(item => {
        if (item.querySelector('.dropdown-toggle')) {
            item.querySelector('.nav-link').addEventListener('click', function(e) {
                if (window.innerWidth <= 992) {
                    e.preventDefault();
                    const dropdownMenu = item.querySelector('.dropdown-menu');
                    const dropdownToggle = item.querySelector('.dropdown-toggle');
                    
                    // Close all other dropdowns
                    document.querySelectorAll('.dropdown-menu').forEach(menu => {
                        if (menu !== dropdownMenu) {
                            menu.classList.remove('active');
                        }
                    });
                    
                    // Close all other dropdown toggles
                    document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
                        if (toggle !== dropdownToggle) {
                            toggle.classList.remove('rotated');
                        }
                    });
                    
                    // Toggle current dropdown
                    dropdownMenu.classList.toggle('active');
                    dropdownToggle.classList.toggle('rotated');
                }
            });
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-menu') && !e.target.closest('.mobile-toggle')) {
            navMenu.classList.remove('active');
            mobileToggle.innerHTML = '☰';
            document.body.style.overflow = '';
            
            // Close all dropdowns
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.classList.remove('active');
            });
            
            // Reset all dropdown toggles
            document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
                toggle.classList.remove('rotated');
            });
        }
    });
    
    // Close menu when clicking on links
    document.querySelectorAll('.dropdown-link').forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 992) {
                navMenu.classList.remove('active');
                mobileToggle.innerHTML = '☰';
                document.body.style.overflow = '';
            }
        });
    });
});


// core/static/core/script.js
document.addEventListener('DOMContentLoaded', () => {
    // Add animation to hero text
    const heroText = document.querySelector('.hero-text');
    setTimeout(() => {
        heroText.style.opacity = '1';
        heroText.style.transform = 'translateY(0)';
    }, 300);
});